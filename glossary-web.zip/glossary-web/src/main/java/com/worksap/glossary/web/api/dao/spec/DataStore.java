package com.worksap.glossary.web.api.dao.spec;

import java.io.IOException;

public interface DataStore {
	Transaction begin() throws IOException;
}
