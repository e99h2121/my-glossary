package com.worksap.glossary.web.api.vo;

import java.util.List;

import lombok.Value;

@Value
public class GlossarySearchResult {
	private final GlossarySearchQuery query;
	private final Hit hit;
	private final List<Glossary> glossaries;
}
