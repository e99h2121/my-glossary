package com.worksap.glossary.web.api.vo;

import lombok.Value;

@Value
public class GlossarySearchQuery {
	private final String id;
	private final String ja;
	private final String en;
	private final String remarks;
	private final String product;
	private final String source;
	private final int begin;
	private final int end;
}
