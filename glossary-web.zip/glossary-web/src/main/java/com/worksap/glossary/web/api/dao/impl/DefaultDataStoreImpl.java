package com.worksap.glossary.web.api.dao.impl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Objects;

import javax.sql.DataSource;

import com.worksap.glossary.web.api.dao.spec.DataStore;
import com.worksap.glossary.web.api.dao.spec.Transaction;
import com.worksap.glossary.web.api.exception.TransactionException;

public class DefaultDataStoreImpl implements DataStore {

	private DataSource dataSource;

	public DefaultDataStoreImpl(DataSource dataSource) {
		this.dataSource = Objects.requireNonNull(dataSource);
	}

	@Override
	public Transaction begin() throws IOException {
		try {
			return new DefaultTransaction(dataSource.getConnection());
		} catch (SQLException e) {
			throw new TransactionException("Connection open failure", e);
		}
	}

}
