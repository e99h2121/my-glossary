package com.worksap.glossary.web.api.service.impl;

import com.worksap.glossary.web.api.dao.impl.DefaultDaoFactory;
import com.worksap.glossary.web.api.dao.spec.DaoFactory;
import com.worksap.glossary.web.api.service.spec.GlossaryService;
import com.worksap.glossary.web.api.service.spec.ServiceFactory;

public class DefaultServiceFactory implements ServiceFactory {
	private DaoFactory daoFactory;

	public DefaultServiceFactory() {
		this(new DefaultDaoFactory());
	}

	public DefaultServiceFactory(DaoFactory daoFactory) {
		this.daoFactory = daoFactory;
	}

	@Override
	public GlossaryService getGlossaryService() {
		return new DefaultGlossaryService(
				daoFactory.getDataStore(),
				daoFactory.getGlossaryDao(),
				getHitCalcurator(),
				getDtoConverter());
	}

	private HitCalculator getHitCalcurator() {
		return new HitCalculator();
	}

	private DtoConverter getDtoConverter() {
		return new DtoConverter();
	}

}
