package com.worksap.glossary.web.api.dao.spec;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import com.worksap.glossary.web.api.dto.GlossaryDto;
import com.worksap.glossary.web.api.vo.GlossarySearchQuery;

public interface GlossaryDao {

	/**
	 * Count total quantity for the query without considering range
	 *
	 * @param connection
	 * @param query
	 * @param today Reference date (include the today)
	 * @return Total quantity
	 * @throws IOException
	 */
	int countWithQuery(Transaction transaction, GlossarySearchQuery query, LocalDate today) throws IOException;
	/*
	 * Why IOException?
	 *
	 * Data access object (DAO) is an object that provides an interface to access data.
	 * It means accessing database in most case.
	 *
	 * But throwing SQLException is not always best choice to indicate the data accessing exception.
	 * Some kinds of data may possibly be not locate in relational databases.
	 * Files, Key Value Store and many type of database (NoSQL) can be used.
	 * Users of DAO do not have to know such details.
	 */

	/**
	 * Search available books with the query
	 *
	 * @param connection
	 * @param query
	 * @param today Reference date (include the today)
	 * @return glossary list (cannot be null) in order by JA
	 * @throws IOException
	 */
	List<GlossaryDto> searchWithQueryOrderById(Transaction transaction, GlossarySearchQuery query, LocalDate today) throws IOException;

}
