package com.worksap.glossary.web.api.service.mock;

import com.worksap.glossary.web.api.service.spec.GlossaryService;
import com.worksap.glossary.web.api.service.spec.ServiceFactory;

/**
 * Creates instances of services
 *
 * User of services must create instances from this object to replace their implementation easily.
 *
 * Many library provides more convenient mechanism (Dependency Injection Container),
 * but it is too complex for beginners.
 */
public class MockServiceFactory implements ServiceFactory {
	@Override
	public GlossaryService getGlossaryService() {
		return new MockGlossaryService();
	}
}
