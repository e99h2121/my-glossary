package com.worksap.glossary.web.api.dao.impl;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Objects;

import com.worksap.glossary.web.api.dao.spec.Transaction;

public class DefaultTransaction implements Transaction {

	private Connection connection;

	public DefaultTransaction(Connection connection) {
		this.connection = Objects.requireNonNull(connection);
	}

	@Override
	public Connection getJdbcConnection() {
		return Objects.requireNonNull(connection);
	}

	@Override
	public void close() throws IOException {
		Objects.requireNonNull(connection);
		try {
			// It is STRONGLY RECOMMENDED that an application explicitly commits or rolls back
			connection.rollback();
		} catch (SQLException t) {
			closeInternal(t);
		} finally {
			closeInternal(null);
			connection = null;
		}
	}

	private void closeInternal(Throwable caught) throws IOException {
		if (connection == null) {
			return;
		}

		try {
			connection.close();
			connection = null;

			if (caught != null) {
				throw new IOException("Rollback failure", caught);
			}
		} catch (SQLException e) {
			IOException exception = new IOException("Connection close failure", e);
			if (caught != null) {
				exception.addSuppressed(caught);
			}
			throw exception;
		}
	}

	@Override
	public void commit() throws IOException {
		Objects.requireNonNull(connection);
		try {
			connection.commit();
		} catch (SQLException e) {
			throw new IOException("Commit failure", e);
		}
	}

	@Override
	public void rollback() throws IOException {
		Objects.requireNonNull(connection);
		try {
			connection.rollback();
		} catch (SQLException e) {
			throw new IOException("Rollback failure", e);
		}
	}

}
