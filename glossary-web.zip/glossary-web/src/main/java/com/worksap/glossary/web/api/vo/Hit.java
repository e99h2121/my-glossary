package com.worksap.glossary.web.api.vo;

import lombok.Value;

/**
 * Value object for a general paginated result.
 */
@Value
public class Hit {
	private final int total;
	private final int begin;
	private final int end;
}
