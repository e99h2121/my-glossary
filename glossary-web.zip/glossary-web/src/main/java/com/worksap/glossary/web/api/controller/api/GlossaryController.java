package com.worksap.glossary.web.api.controller.api;

import java.time.LocalDate;

import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.worksap.glossary.web.api.service.impl.DefaultServiceFactory;
import com.worksap.glossary.web.api.service.spec.GlossaryService;
import com.worksap.glossary.web.api.service.spec.ServiceFactory;
import com.worksap.glossary.web.api.vo.GlossarySearchQuery;
import com.worksap.glossary.web.api.vo.GlossarySearchResult;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Path("glossary")
@Slf4j
public class GlossaryController {

	/**
	 * Non-validated query for searching books
	 */
	@Data
	private static class RequestedGlossarySearchQuery {
		@QueryParam("id") private String id;
		@QueryParam("ja") private String ja;
		@QueryParam("en") private String en;
		@QueryParam("remarks") private String remarks;
		@QueryParam("product") private String product;
		@QueryParam("source") private String source;
		@QueryParam("begin") private Integer start;
		@QueryParam("end") private Integer end;
		
		public GlossarySearchQuery toVo() {
			return new GlossarySearchQuery(
					id,
					ja,
					en,
					remarks,
					product,
					source,
					start != null ? start : 0,
					end != null ? end : Integer.MAX_VALUE
			);
		}
	}

	@Path("search")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public GlossarySearchResult getGlossary(@BeanParam RequestedGlossarySearchQuery query) {
		log.trace("GET glossary/search: query = {}", query);

		ServiceFactory sf = new DefaultServiceFactory();
		GlossaryService glossaryService = sf.getGlossaryService();

		GlossarySearchResult result = glossaryService.search(query.toVo(), LocalDate.now());

		log.trace("GET glossary/search: result = {}", result);
		return result;
	}
}
