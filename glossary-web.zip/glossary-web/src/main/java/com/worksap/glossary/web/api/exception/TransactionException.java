package com.worksap.glossary.web.api.exception;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

/**
 * Exception while handling transaction.
 *
 * It occur when the system cannot complete transaction successfully.
 * This exception is caused from bug of usage or physical problem.
 *
 * Framework often provides way to handle exception.
 * In JAX-RS, one of way is using {@link WebApplicationException}.
 * It can take {@link Response} to response exceptional view (not used in this time).
 */
public class TransactionException extends WebApplicationException {

	private static final long serialVersionUID = -2846596261479539410L;

	public TransactionException(String message, Exception e) {
		super(message, e);
	}

	public TransactionException(String message) {
		super(message);
	}

}
