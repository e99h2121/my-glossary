package com.worksap.glossary.web.api.service.mock;

import java.time.LocalDate;

import com.worksap.glossary.web.api.service.spec.GlossaryService;
import com.worksap.glossary.web.api.vo.Glossary;
import com.worksap.glossary.web.api.vo.GlossarySearchQuery;
import com.worksap.glossary.web.api.vo.GlossarySearchResult;
import com.worksap.glossary.web.api.vo.Hit;

import jersey.repackaged.com.google.common.collect.ImmutableList;

public class MockGlossaryService implements GlossaryService {
	@Override
	public GlossarySearchResult search(GlossarySearchQuery query, LocalDate now) {
		return new GlossarySearchResult(
				query,
				new Hit(200, 100, 120),
				ImmutableList.of(
						new Glossary("1", "�Ă���1", "test1", "test remark", "CJK","test source"),
						new Glossary("2", "�Ă���2", "test2", "test remark", "CJK","test source"),
						new Glossary("3", "�Ă���3", "test3", "test remark", "CJK","test source"),
						new Glossary("4", "�Ă���4", "test4", "test remark", "AC","test source"),
						new Glossary("5", "�Ă���5", "test5", "test remark", "SCM","test source")
				)
		);
	}
}
