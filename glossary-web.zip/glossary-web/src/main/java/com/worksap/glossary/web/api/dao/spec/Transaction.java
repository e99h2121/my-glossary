package com.worksap.glossary.web.api.dao.spec;

import java.io.IOException;
import java.sql.Connection;

public interface Transaction extends AutoCloseable {
	Connection getJdbcConnection();

	@Override
	void close() throws IOException;

	void commit() throws IOException;

	void rollback() throws IOException;
}
