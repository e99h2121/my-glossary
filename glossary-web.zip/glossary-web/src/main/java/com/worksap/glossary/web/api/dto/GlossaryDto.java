package com.worksap.glossary.web.api.dto;

import java.time.LocalDate;

import lombok.Value;

@Value
public class GlossaryDto {
	private final String id;
	private final String ja;
	private final String en;
	private final String remarks;
	private final String product;
	private final String source;
	private final LocalDate create;
	private final LocalDate update;
}
