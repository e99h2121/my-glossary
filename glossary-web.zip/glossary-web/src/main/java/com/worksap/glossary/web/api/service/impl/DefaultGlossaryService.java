package com.worksap.glossary.web.api.service.impl;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import lombok.extern.slf4j.Slf4j;

import com.worksap.glossary.web.api.dao.spec.DataStore;
import com.worksap.glossary.web.api.dao.spec.GlossaryDao;
import com.worksap.glossary.web.api.dao.spec.Transaction;
import com.worksap.glossary.web.api.dto.GlossaryDto;
import com.worksap.glossary.web.api.exception.TransactionException;
import com.worksap.glossary.web.api.service.spec.GlossaryService;
import com.worksap.glossary.web.api.vo.Glossary;
import com.worksap.glossary.web.api.vo.GlossarySearchQuery;
import com.worksap.glossary.web.api.vo.GlossarySearchResult;
import com.worksap.glossary.web.api.vo.Hit;

@Slf4j
public class DefaultGlossaryService implements GlossaryService {

	private DataStore dataStore;
	private GlossaryDao glossaryDao;
	private HitCalculator hitCalcurator;
	private DtoConverter dtoConverter;

	public DefaultGlossaryService(
			DataStore dataStore,
			GlossaryDao glossaryDao,
			HitCalculator hitCalcurator,
			DtoConverter dtoConverter) {
		this.dataStore = Objects.requireNonNull(dataStore);
		this.glossaryDao = Objects.requireNonNull(glossaryDao);
		this.hitCalcurator = Objects.requireNonNull(hitCalcurator);
		this.dtoConverter = Objects.requireNonNull(dtoConverter);
	}

	@Override
	public GlossarySearchResult search(GlossarySearchQuery query, LocalDate today) {
		Objects.requireNonNull(query);
		Objects.requireNonNull(today);
		if (query.getBegin() < 0 || query.getEnd() < query.getBegin()) {
			throw new IllegalArgumentException("Bad query: " + query.toString());
		}
		try (Transaction transaction = dataStore.begin()) {
			final int glossaryQuantity = glossaryDao.countWithQuery(transaction, query, today);

			List<GlossaryDto> glossaryDtoList = glossaryDao.searchWithQueryOrderById(transaction, query, today);
			
			final Hit hit = hitCalcurator.calculate(query.getBegin(), query.getEnd(), glossaryQuantity);
			final List<Glossary> glossaries = dtoConverter.toGlossaryList(glossaryDtoList);
			return new GlossarySearchResult(query, hit, glossaries);
		} catch (IOException e) {
			String message = String.format("Please check inconsitency and the database status: query = %s, today = %s",
					query, today);
			log.error(message);
			throw new TransactionException("Exception occured while handling transaction", e);
			
		}
	
	}

}
