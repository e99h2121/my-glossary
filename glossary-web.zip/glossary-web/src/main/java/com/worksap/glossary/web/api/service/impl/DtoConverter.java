package com.worksap.glossary.web.api.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.worksap.glossary.web.api.dto.GlossaryDto;
import com.worksap.glossary.web.api.vo.Glossary;

class DtoConverter {
	/**
	 * URL for a dummy book image.
	 *
	 * "/ss-api-lv1" is called context path. We can get it from ServletContext.
	 * But to begin with, it is problem that application server (Tomcat in this time) should not send image.
	 * The most web server (Apache HTTP Aerver, Nginx and etc.) can send static contents well.
	 * It is enough exceptionally in this time even if it was included
	 * because it should be given from external configuration really.
	 */
//	private static final String DUMMY_IMAGE_URL = "/ss-api-lv1/img/dummy.png";

	List<Glossary> toGlossaryList(List<GlossaryDto> glossaryDtoList) {
		List<Glossary> result = new ArrayList<>(glossaryDtoList.size());
		for (GlossaryDto glossaryDto : glossaryDtoList) {
			// Replace to dummy picture if not present
//			String picture = glossaryDto.getPicture();
//			if (picture == null || "".equals(picture)) {
//				picture = DUMMY_IMAGE_URL;
//			}
			result.add(new Glossary(glossaryDto.getId(), glossaryDto.getJa(), glossaryDto.getEn(), glossaryDto.getRemarks(), glossaryDto.getProduct(), glossaryDto.getSource()));
		}
		return result;
	}
}
