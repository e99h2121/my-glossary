package com.worksap.glossary.web.api.dao.impl;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import lombok.extern.slf4j.Slf4j;

import com.worksap.glossary.web.api.dao.spec.GlossaryDao;
import com.worksap.glossary.web.api.dao.spec.Transaction;
import com.worksap.glossary.web.api.dto.GlossaryDto;
import com.worksap.glossary.web.api.vo.GlossarySearchQuery;

@Slf4j
public class DefaultGlossaryDaoImpl implements GlossaryDao {

	@Override
	public int countWithQuery(Transaction transaction, GlossarySearchQuery query, LocalDate today) throws IOException {
		Objects.requireNonNull(transaction);
		Objects.requireNonNull(query);
		Objects.requireNonNull(today);
		
		Connection connection = transaction.getJdbcConnection();
		String sql = generateCountWithQuerySQL(query, today);
		log.trace("countWithQuery: generated SQL = {}", sql);
		try (PreparedStatement statement = connection.prepareStatement(sql)) {
			applyCountWithQueryValues(statement, query, today);
			ResultSet result = statement.executeQuery();
			if (result.next()) {
				int index = 0;
				return result.getInt(++ index);
			}
			throw new IOException("No result");
		} catch (SQLException e) {
			log.error("Execution failure", e);
			throw new IOException(e);
		}
	}
	
	private void applyCountWithQueryValues(PreparedStatement statement,
			GlossarySearchQuery query, LocalDate today) throws SQLException {
		int index = 0;
		applySearchQueryValues(statement, query, today, index);
	}

	private String generateCountWithQuerySQL(GlossarySearchQuery query, LocalDate today) {
		StringBuilder sql = new StringBuilder(
				"SELECT COUNT(*) FROM public.glossary g WHERE 1=1 ");
		generateSearchQuerySQL(query, today, sql);
		return sql.toString();
	}

	@Override
	public List<GlossaryDto> searchWithQueryOrderById(Transaction transaction, GlossarySearchQuery query, LocalDate today)
			throws IOException {
		Objects.requireNonNull(transaction);
		Objects.requireNonNull(query);
		Objects.requireNonNull(today);
		
		Connection connection = transaction.getJdbcConnection();
		String sql = generateSearchWithQuerySQL(query, today);
		log.trace("searchWithQueryOrderById: generated SQL = {}", sql);
		try (PreparedStatement statement = connection.prepareStatement(sql)) {
			applySearchWithQueryOrderByIdValues(statement, query, today);
			ResultSet resultSet = statement.executeQuery();
			List<GlossaryDto> list = readRowsAsGlossaryDtoList(resultSet);
			return list;
		} catch (SQLException e) {
			log.error("Execution failure", e);
			throw new IOException(e);
		}
		
	}

	private void applySearchWithQueryOrderByIdValues(
			PreparedStatement statement, GlossarySearchQuery query, LocalDate today)
			throws SQLException {
		int index = 0;
		index = applySearchQueryValues(statement, query, today, index);
 
		statement.setInt(++index, query.getBegin() + 1);
		statement.setInt(++index, query.getEnd());
	}
	
	private String generateSearchWithQuerySQL(GlossarySearchQuery query, LocalDate today) {
		StringBuilder sql = new StringBuilder(
				"SELECT g.id, g.ja, g.en, g.remarks, g.product, g.source, g.create, g.update "
						+ " FROM public.glossary g  WHERE 1=1 ");

		generateSearchQuerySQL(query, today, sql);
		sql.append(" ORDER BY g.ja");
		return wrapToClipSQL(sql);
	}

	private List<GlossaryDto> readRowsAsGlossaryDtoList(ResultSet resultSet) throws SQLException {
		List<GlossaryDto> result = new ArrayList<GlossaryDto>();
		while (resultSet.next()) {
			result.add(readRowAsGlossaryDto(resultSet));
		}
		return result;
	}
	
	private GlossaryDto readRowAsGlossaryDto(ResultSet resultSet) throws SQLException {
		int columnIndex = 0;
		String id = resultSet.getString(++columnIndex);
		String ja = resultSet.getString(++columnIndex);
		String en = resultSet.getString(++columnIndex);
		String remarks = resultSet.getString(++columnIndex);
		String product = resultSet.getString(++columnIndex);
		String source = resultSet.getString(++columnIndex);
		LocalDate create = resultSet.getDate(++columnIndex).toLocalDate();
		LocalDate update = resultSet.getDate(++columnIndex).toLocalDate();
		return new GlossaryDto(id, ja, en, remarks, product, source, create, update);
	}
	
	private String wrapToClipSQL(CharSequence sql) {
		// Some databases support OFFSET and LIMIT, but they are not standard.
		// Oracle database (most used in enterprise) does not support until
		// recent version.
		return String.format("SELECT * FROM (SELECT *, ROWNUM rn FROM (%s)) WHERE rn BETWEEN ? AND ?", sql);
	}

	private void generateSearchQuerySQL(GlossarySearchQuery query, LocalDate today, StringBuilder sql) {
		String ja = query.getJa();
		if (ja != null && !ja.isEmpty()) {
			sql.append(" AND g.ja LIKE '%'||?||'%'");
		}

		String en = query.getEn();
		if (en != null && !en.isEmpty()) {
			sql.append(" AND g.en LIKE '%'||?||'%'");
		}
	}

	private int applySearchQueryValues(PreparedStatement statement, GlossarySearchQuery query, LocalDate today, int index)
			throws SQLException {
		String ja = query.getJa();
		if (ja != null && !ja.isEmpty()) {
			statement.setString(++index, ja);
		}

		String en = query.getEn();
		if (en != null && !en.isEmpty()) {
			statement.setString(++index, en);
		}
		return index;
	}

//	private static final String SEARCH_WITH_CART_ID_SQL =
//			"SELECT b.book_id, b.title, b.publisher_id, b.isbn, b.price, b.picture, b.release_date, b.prc_date"
//			+ " FROM books b, cart_books cb WHERE b.book_id=cb.book_id AND cb.cart_id=? AND b.release_date<=?";

//	@Override
//	public List<GlossaryDto> searchWithCartId(Transaction transaction, int cartId, LocalDate today) throws IOException {
//		Objects.requireNonNull(transaction);
//		Objects.requireNonNull(today);
//
//		Connection connection = transaction.getJdbcConnection();
//		String sql = SEARCH_WITH_CART_ID_SQL;
//		log.trace("searchWithCartId: generated SQL = {}", sql);
//		
//		try (PreparedStatement statement = connection.prepareStatement(sql)) {
//			applySearchWithCartIdValues(statement, cartId, today);
//			ResultSet resultSet = statement.executeQuery();
//			return readRowsAsGlossaryDtoList(resultSet);
//		} catch (SQLException e) {
//			log.error("Execution failure", e);
//			throw new IOException(e);
//		}
//	}

//	private void applySearchWithCartIdValues(PreparedStatement statement, int cartId, LocalDate today) throws SQLException {
//		int index = 0;
//		statement.setInt(++index, cartId);
//		Date todayDate = Date.from(today.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
//		statement.setDate(++index, new java.sql.Date(todayDate.getTime()));
//	}

}