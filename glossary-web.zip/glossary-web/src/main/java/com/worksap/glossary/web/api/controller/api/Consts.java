package com.worksap.glossary.web.api.controller.api;

public final class Consts {
	/**
	 * Key for session id cookie. In this project, it is used as substitute for user id
	 *
	 * Normally, DO NOT HANDLE SESSION ID DIRECTLY.
	 * Session ID is very important value in user authentication.
	 * It can cause impersonation (identity theft) when it is leaked.
	 * In product development, treat with extreme caution.
	 */
	public static final String SESSION_ID = "JSESSIONID";
}
