package com.worksap.glossary.web.api.service.spec;

import java.time.LocalDate;

import com.worksap.glossary.web.api.vo.GlossarySearchQuery;
import com.worksap.glossary.web.api.vo.GlossarySearchResult;

public interface GlossaryService {

	/**
	 * Search book
	 * @param query
	 * @param today Reference date (include the today)
	 * @return
	 */
	GlossarySearchResult search(GlossarySearchQuery query, LocalDate today);
}
