package com.worksap.glossary.web.api.service.impl;

import com.worksap.glossary.web.api.vo.Hit;

/**
 * Shared service for default implementations to calculate {@link Hit}
 */
class HitCalculator {

	Hit calculate(int queryBegin, int queryEnd, int totalQuantity) {
		requirePositiveOrZero(queryBegin);
		requirePositiveOrZero(queryEnd);
		requirePositiveOrZero(totalQuantity);
		if (queryEnd < queryBegin) {
			throw new IllegalArgumentException(
					String.format("Bad queryBegin (%d) and queryEnd (%d)", queryBegin, queryEnd));
		}

		int total = totalQuantity;
		int begin = queryBegin;
		int end = queryEnd;

		if (begin > totalQuantity) {
			begin = totalQuantity;
		}
		if (end > totalQuantity) {
			end = totalQuantity;
		}
		return new Hit(total, begin, end);
	}

	private void requirePositiveOrZero(int value) {
		if (value < 0) {
			throw new IllegalArgumentException("The value must be positive or 0");
		}
	}

}
