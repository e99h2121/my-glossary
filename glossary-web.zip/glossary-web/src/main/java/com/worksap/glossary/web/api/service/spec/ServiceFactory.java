package com.worksap.glossary.web.api.service.spec;

/**
 * Creates instances of services
 *
 * User of services must create instances from this object to replace their
 * implementation easily.
 *
 * Many library provides more convenient mechanism (Dependency Injection
 * Container), but it is too complex for beginners.
 */
public interface ServiceFactory {
	GlossaryService getGlossaryService();
}
