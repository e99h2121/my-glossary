package com.worksap.glossary.web.api.filter;

import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.Priority;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.ext.Provider;

import org.glassfish.jersey.server.filter.CsrfProtectionFilter;

import lombok.extern.slf4j.Slf4j;

/**
 * {@link CsrfProtectionFilter} is not enough to protect CSRF on prerequisite of XHR2.
 * Current modern browsers allow sending cross-origin XHR requests.
 */
@Priority(Priorities.AUTHENTICATION)
@Provider
@Slf4j
public class CsrfProtectionForXhr2Filter implements ContainerRequestFilter {

	private static final Set<String> METHODS_TO_IGNORE;

	static {
		HashSet<String> mti = new HashSet<>();
		mti.add("GET");
		mti.add("OPTIONS");
		mti.add("HEAD");
		METHODS_TO_IGNORE = Collections.unmodifiableSet(mti);
	}

	private static final String HOST_HEADER_NAME = "Host";
	/**
	 * Name of the header this filter will attach to the request.
	 */
	public static final String HEADER_NAME = "X-Requested-With";
	private static final String ORIGIN_HEADER_NAME = "Origin";

	public static final String EXPECTED_HOST = "localhost:8080";
	public static final String EXPECTED_ORIGIN = "http://" + EXPECTED_HOST;

	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		if (METHODS_TO_IGNORE.contains(requestContext.getMethod())) {
			log.trace("Method: OK");
			return;
		}
		if (isExpectedHost(requestContext.getHeaderString(HOST_HEADER_NAME))
				&& requestContext.getHeaders().containsKey(HEADER_NAME) // Must be XHR request, not form
				&& isSameOrigin(requestContext.getHeaderString(ORIGIN_HEADER_NAME))) {
			log.trace("Expcted Origin: OK");
			return;
		}
		log.trace("Cross-origin request is not permitted");
		throw new BadRequestException();
	}

	/**
	 * It is need to check host name, not only origin header.
	 * There is possibility to through protection by DNS rebinding.
	 *
	 * @param host
	 * @return
	 */
	private boolean isExpectedHost(String host) {
		return EXPECTED_HOST.equals(host);
	}

	private boolean isSameOrigin(String origin) {
		if (origin == null) {
			// It is a same origin request if the origin header is not present
			// Browser must add 'Origin' header when it send cross origin request.
			// It is not have to add the header when it send same origin request,
			// but most modern browsers (at least Chrome and Firefox) always send the header.
			// And old browser cannot send cross origin request.
			return true;
		}
		return EXPECTED_ORIGIN.equals(origin);
	}

}
