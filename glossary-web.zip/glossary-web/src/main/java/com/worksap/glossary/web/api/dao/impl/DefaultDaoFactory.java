package com.worksap.glossary.web.api.dao.impl;

import java.sql.SQLException;
import java.util.Objects;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.worksap.glossary.web.api.dao.spec.DaoFactory;
import com.worksap.glossary.web.api.dao.spec.DataStore;
import com.worksap.glossary.web.api.dao.spec.GlossaryDao;
import com.worksap.glossary.web.api.exception.TransactionException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DefaultDaoFactory implements DaoFactory {

	public static String DATASOURCE_NAME = "java:comp/env/jdbc/glossary/datasource";

	private DataSource dataSource;

	// Visible For Testing
	DataSource getDataSource() {
		try {
			if (dataSource == null) {
				// Get DataSouce from Java Naming and Directory Interface (JDNI).
				// JDNI service is ordinarily provided by application server (Tomcat, WebSphere or etc.).
				InitialContext context = new InitialContext();
				dataSource = (DataSource) Objects.requireNonNull(context.lookup(DATASOURCE_NAME));
				dataSource.getConnection().setAutoCommit(false);
			}
			return dataSource;
		} catch (NamingException e) {
			String message = String.format(
					"DataSource %s was not found."
							+ " Please check the context configuration for the server.",
							DATASOURCE_NAME);
			log.error(message, e);
			throw new TransactionException(message, e);
		} catch (SQLException e) {
			String message = String.format(
					"DataSource %s cannot use."
							+ " Please check the context configuration for the server.",
							DATASOURCE_NAME);
			log.error(message, e);
			throw new TransactionException(message, e);
		}
	}

	@Override
	public GlossaryDao getGlossaryDao() {
		return new DefaultGlossaryDaoImpl();
	}

	@Override
	public DataStore getDataStore() {
		return new DefaultDataStoreImpl(getDataSource());
	}

}
