package com.worksap.glossary.web.api.dao.spec;

public interface DaoFactory {

	GlossaryDao getGlossaryDao();

	DataStore getDataStore();

}
