'use strict';

/* Model */

/*
 * Classes of the model hides details of saving data.
 *
 * Many type of data store (memory, Web storage, cookie, ...) are used.
 * It will be difficult to change to state-of-the-art data store in the future
 * if these implementation spread to many place of code.
 * Developers who want to use model do not have to know details of data stores
 * when the models provides appropriate interfaces.
 *
 * Models also adapt the changes of interface.
 * For example, the end-point URL parameter and key names
 * are required to invoke API when you want to send data to server.
 * Only changing models can handle these changes.
 */

var obs = obs || {};
obs.model = obs.model || {};

obs.model.glossary = {
	searchGlossary: function(query) {
		util.log(query);
		return $.ajax({
			url: 'api/glossary/search',
			data: {
				id: query.id,
				ja: query.ja,
				en: query.en,
				remarks: query.remarks,
				product: query.product,
				source: query.source,
				begin: query.begin,
				end: query.end,
			},
		});
	},
};
