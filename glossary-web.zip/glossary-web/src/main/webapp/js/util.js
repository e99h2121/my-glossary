'use strict';

var DEBUG = DEBUG || false;

/* Utility */

var util = util || {};

if (DEBUG) {
	util.log = function() {
		console.log.apply(console, arguments);
	};
} else {
	util.log = function() { /* Do nothing */ };
}
