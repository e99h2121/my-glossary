'use strict';

/* Controller */

/*
 * This is Controller (some people call ViewModel, Octopus, etc.) for index.jsp.
 *
 * It is connect between DOM-related operations (View) and data-related operations (Model).
 * If you connect them directly, it will be complex and difficult system.
 * Because models consider many case of views and views consider many case of models.
 * The connections can be (Model * View) patterns in such case.
 * Although, maximum number of connections is (Model + View) when you use Controller.
 *
 * There are many ways of writing to put it into practice
 * but the essence is splitting application to 3 roles and these connections.
 */


/*
 * $(function) execute when the DOM is fully loaded.
 */
$(function() {
    // initial search
    obs.model.glossary.searchGlossary(obs.view.paginator.toRange(0))
        .done(function(result) {
            util.log(result);
            obs.view.glossaryList.render(result.glossaries, result.query);
        });
 
});
$(function() {
	function onSearchResultReceived(result) {
		util.log(result);
	    obs.view.glossaryList.render(result.glossaries, result.query);
	    obs.view.paginator.render(result.hit);
	}

	obs.view.searchBox.init($('.search-box'), {
		onMovePage: function(newPage) {
	        var searchQuery = obs.view.searchBox.getSearchQuery();
	        var pageQuery = obs.view.paginator.toRange(newPage);
	        var query = $.extend({}, searchQuery, pageQuery);
	        util.log(query);
	        obs.model.glossary.searchGlossary(query)
	            .done(onSearchResultReceived);
		},
		onSearchButtonClicked: function() {
			// TODO Execute search and show result
	        var searchQuery = obs.view.searchBox.getSearchQuery();
	        var pageQuery = obs.view.paginator.toRange(0);
	        var query = $.extend({}, searchQuery, pageQuery);
	        util.log(query);
	        obs.model.glossary.searchGlossary(query)
	            .done(onSearchResultReceived);
		}
		
	});

	obs.view.glossaryList.init($('.glossary-list'), {
	});

	obs.view.paginator.init($('.paginator'), {
		onMovePage: function(newPage) {
			var searchQuery = obs.view.searchBox.getSearchQuery();
			var pageQuery = obs.view.paginator.toRange(newPage);
			var query = $.extend({}, searchQuery, pageQuery);
			util.log(query);
			// Execute search and show result
			obs.model.glossary.searchGlossary(query).done(onSearchResultReceived);
		},
	});

	// initial search
	obs.model.glossary.searchGlossary(obs.view.paginator.toRange(0))
    .done(onSearchResultReceived);
	
});
