'use strict';

/* View */

/*
 * View objects represent the sub tree.
 *
 * They provides an abstract of DOM structure and operations to use from JavaScript.
 * You invoke the related view methods when you want to change the DOM structure to fix design.
 *
 * HTML writers can know how structure and what tag and attributes are needed for JavaScript.
 * JavaScript writer who use it from Controller can know features without the details of design.
 * It is enough to know what function user can call and what events user can listen.
 */

/* namespace idiom */
var obs = obs || {};
obs.view = obs.view || {};

(function() {
	var elements = {
		$queryText: null,
		$searchType: null,
	};

	obs.view.searchBox = {
		init: function($parent, handlers) {
			elements.$searchType = $parent.children('.search-type');
			elements.$queryText = $parent.children('input');

			$parent.children('.search-button').on('click', function() {
		        handlers.onSearchButtonClicked(obs.view.searchBox.getSearchQuery());
		      });
		},
		getSearchQuery: function() {
			var queryText = elements.$queryText.val();
			if (queryText) {
				switch (elements.$searchType.val()) {
				case 'ja':
					return { ja: queryText };
				case 'en':
					return { en: queryText };
				}
			}
			return {};
		},
	};
})();


(function() {
	var GLOSSARY_TEMPLATE = $('#glossary-template');
	
	var elements = {
		$glossaries: null,
		$glossarySearchTitle: null,
	};
 
	obs.view.glossaryList = {
		init: function($parent, handlers) {
			elements.$glossaries = $parent.children('.glossaries');
			elements.$glossarySearchTitle = $parent.children('.glossary-search-ja');
 
			obs.model.glossary.searchGlossary(obs.view.paginator.toRange(0))
			.done(function(result) {
				util.log(result);
				obs.view.glossaryList.render(result.glossary, result.query);
			});
		},
		render: function(glossaries, query) {
			// Search title
			var text;
			if (query.ja) {
				text = '日本語❝' + query.ja + '❞の検索結果';
			} else if (query.en) {
				text = 'English❝' + query.en + '❞の検索結果';
			} else {
				text = '';
			}
			elements.$glossarySearchTitle.text(text);
			// Glossary list
			elements.$glossaries.empty();
			elements.$glossaries.append(GLOSSARY_TEMPLATE.render(glossaries));
		},
	};
})();


(function() {
	var GLOSSARY_PER_PAGE = 20;
	var PAGINATOR_TEMPLATE = $('#paginator-template');
	var elements = {
		$parent: null,
	};

	obs.view.paginator = {
		init: function($parent, handlers) {
			elements.$parent = $parent;
			/*
			 * At initializing, the buttons does not exist.
			 * Then 2nd argument (selector) of `on` filter out other elements.
			 * This code listen all click event of children (including indirect ones),
			 * but function is called only when the element is button.
			 *
			 * http://api.jquery.com/on/
			 */
			$parent.on('click', 'button', function(event) {
				var pageNumber = $(event.target).val() - 1;
				handlers.onMovePage(pageNumber);
			});
		},
		toRange: function(page) {
			return {
				begin: page * GLOSSARY_PER_PAGE,
				end: (page + 1) * GLOSSARY_PER_PAGE,
			};
		},
	    render : function(hit) {
	        elements.$parent.empty();
	        elements.$parent.append(PAGINATOR_TEMPLATE.render({
	          begin : hit.begin + 1,
	          end : hit.end,
	          total : hit.total,
	          current : Math.floor(hit.begin / GLOSSARY_PER_PAGE) + 1,
	          last : Math.floor(hit.total / GLOSSARY_PER_PAGE) + 1,
	        }));
	      },
	};
})();
