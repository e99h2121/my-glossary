var gulp = require('gulp');
var less = require('gulp-less');
var cssmin = require('gulp-cssmin');

var argv = require('yargs')
	.argv;

console.log('CSS dest: ' + argv.css);

gulp.task('default', ['build']);
gulp.task('build', ['less']);

gulp.task('less:min', function() {
	return gulp.src(['less/style.less'])
		.pipe(less())
		.pipe(cssmin())
		.pipe(gulp.dest(argv.css));
});

gulp.task('less', function() {
	return gulp.src(['less/style.less'])
		.pipe(less())
		.pipe(gulp.dest(argv.css));
});

