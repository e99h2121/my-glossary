package com.worksap.glossary.web.api.service.impl;

import java.io.IOException;

import com.worksap.glossary.web.api.dao.spec.DataStore;
import com.worksap.glossary.web.api.dao.spec.Transaction;

public class MockDataStoreFailBegin implements DataStore {

	@Override
	public Transaction begin() throws IOException {
		throw new IOException("Thrown for test");
	}

}
