package com.worksap.glossary.web.api.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;

import com.worksap.glossary.web.api.dao.spec.DaoFactory;
import com.worksap.glossary.web.api.dto.GlossaryDto;
import com.worksap.glossary.web.api.exception.TransactionException;
import com.worksap.glossary.web.api.service.impl.DefaultServiceFactory;
import com.worksap.glossary.web.api.service.spec.GlossaryService;
import com.worksap.glossary.web.api.service.spec.ServiceFactory;
import com.worksap.glossary.web.api.vo.Glossary;
import com.worksap.glossary.web.api.vo.GlossarySearchQuery;
import com.worksap.glossary.web.api.vo.GlossarySearchResult;
import com.worksap.glossary.web.api.vo.Hit;

public class DefaultGlossaryServiceImplTest {

	@Test
	public void testSearchOneResult() throws IOException, SQLException {
		DaoFactory mockDaoFactory = createMockDaoFactory(
				1,
				Collections.singletonList(
						//new GlossaryDto("1", "�Ă���1", "test1", "test remark", "CJK", LocalDate.now())));
						new GlossaryDto("1", "�Ă���1", "test1", "test remark", "CJK", "CJK.xls", LocalDate.now(), LocalDate.now())));

		ServiceFactory factory = new DefaultServiceFactory(mockDaoFactory);
		GlossaryService glossaryService = factory.getGlossaryService();
		GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null,null,  0, Integer.MAX_VALUE);
		GlossarySearchResult result = glossaryService.search(query, LocalDate.now());

		Hit hit = result.getHit();
		assertEquals(1, hit.getTotal());
		assertEquals(0, hit.getBegin());
		assertEquals(1, hit.getEnd());

		List<Glossary> books = result.getGlossaries();
		assertEquals(1, books.size());
		assertEquals(new Glossary("1", "�Ă���1", "test1", "test remark", "CJK", "test source"), books.get(0));

		MockTransaction mockTransaction = (MockTransaction) mockDaoFactory.getDataStore().begin();
		assertTrue(mockTransaction.isClosed());
	}

	@Test
	public void testSearchResult() throws IOException, SQLException {
		final int bookTotal = 100;
		List<GlossaryDto> foundBooks = new ArrayList<>();
		int queryEnd = 20;
		for (int i = 0; i < queryEnd; i++) {
			foundBooks.add(new GlossaryDto("1", "�Ă���1", "test1", "test remark", "CJK", "CJK.xls", LocalDate.now(), LocalDate.now()));
		}
		DaoFactory mockDaoFactory = createMockDaoFactory(
				bookTotal,
				foundBooks);

		ServiceFactory factory = new DefaultServiceFactory(mockDaoFactory);
		GlossaryService glossaryService = factory.getGlossaryService();

		GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 0, queryEnd);
		GlossarySearchResult result = glossaryService.search(query, LocalDate.now());

		Hit hit = result.getHit();
		assertEquals(bookTotal, hit.getTotal());
		assertEquals(0, hit.getBegin());
		assertEquals(foundBooks.size(), hit.getEnd());

		List<Glossary> books = result.getGlossaries();
		assertEquals(foundBooks.size(), books.size());
		assertEquals(new Glossary("1", "�Ă���1", "test1", "test remark", "CJK", "test source"), books.get(0));

		MockTransaction mockTransaction = (MockTransaction) mockDaoFactory.getDataStore().begin();
		assertTrue(mockTransaction.isClosed());
	}

	@Test
	public void testSearchInconsistentPublisher() throws IOException, SQLException {
		DaoFactory mockDaoFactory = createMockDaoFactory(
				1,
				Collections.singletonList(
						new GlossaryDto("1", "�Ă���1", "test1", "test remark", "CJK", "CJK.xls", LocalDate.now(), LocalDate.now())));

		ServiceFactory factory = new DefaultServiceFactory(mockDaoFactory);
		GlossaryService glossaryService = factory.getGlossaryService();
		GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 0, Integer.MAX_VALUE);
		GlossarySearchResult result = glossaryService.search(query, LocalDate.now());

		Hit hit = result.getHit();
		assertEquals(1, hit.getTotal());
		assertEquals(0, hit.getBegin());
		assertEquals(1, hit.getEnd());

		List<Glossary> books = result.getGlossaries();
		assertEquals(1, books.size());
		assertEquals(new Glossary("1", "�Ă���1", "test1", "test remark", "CJK", "test source"), books.get(0));

		MockTransaction mockTransaction = (MockTransaction) mockDaoFactory.getDataStore().begin();
		assertTrue(mockTransaction.isClosed());
	}

	@Test
	public void testSearchEmptyResult() throws IOException, SQLException {
		DaoFactory mockDaoFactory = createMockDaoFactory(0, Arrays.asList());

		ServiceFactory factory = new DefaultServiceFactory(mockDaoFactory);

		GlossaryService glossaryService = factory.getGlossaryService();
		GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 0, Integer.MAX_VALUE);
		GlossarySearchResult result = glossaryService.search(query, LocalDate.now());

		Hit hit = result.getHit();
		assertEquals(0, hit.getTotal());
		assertEquals(0, hit.getBegin());
		assertEquals(0, hit.getEnd());

		assertEquals(0, result.getGlossaries().size());

		MockTransaction mockTransaction = (MockTransaction) mockDaoFactory.getDataStore().begin();
		assertTrue(mockTransaction.isClosed());
	}

	@Test(expected = NullPointerException.class)
	public void testSearchWithNullQuery() {
		ServiceFactory factory = new DefaultServiceFactory(
				Mockito.mock(DaoFactory.class, Mockito.RETURNS_DEEP_STUBS));

		GlossaryService glossaryService = factory.getGlossaryService();
		glossaryService.search(null, LocalDate.now());
	}

	@Test(expected = NullPointerException.class)
	public void testSearchWithNullTime() {
		ServiceFactory factory = new DefaultServiceFactory(
				Mockito.mock(DaoFactory.class, Mockito.RETURNS_DEEP_STUBS));

		GlossaryService glossaryService = factory.getGlossaryService();

		GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 0, Integer.MAX_VALUE);
		glossaryService.search(query, null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testSearchWithNegativeBeginIndex() {
		ServiceFactory factory = new DefaultServiceFactory(
				Mockito.mock(DaoFactory.class, Mockito.RETURNS_DEEP_STUBS));

		GlossaryService glossaryService = factory.getGlossaryService();

		GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, -1, Integer.MAX_VALUE);
		glossaryService.search(query, LocalDate.now());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testSearchWithBadRange() {
		ServiceFactory factory = new DefaultServiceFactory(
				Mockito.mock(DaoFactory.class, Mockito.RETURNS_DEEP_STUBS));

		GlossaryService glossaryService = factory.getGlossaryService();

		GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 1, 0);
		glossaryService.search(query, LocalDate.now());
	}

	@Test
	public void testSearchFailDaoMethod() throws IOException, SQLException {
		DaoFactory mockDaoFactory = Mockito.mock(DaoFactory.class, Mockito.RETURNS_DEEP_STUBS);

		MockTransaction mockTransaction = new MockTransaction();
		Mockito.when(mockDaoFactory.getDataStore().begin())
				.thenReturn(mockTransaction);

		String dummyExceptionMessage = "Thrown for test";
		Mockito.when(mockDaoFactory.getGlossaryDao().countWithQuery(Matchers.any(), Matchers.any(), Matchers.any()))
				.thenThrow(new IOException(dummyExceptionMessage));
		Mockito.when(mockDaoFactory.getGlossaryDao().searchWithQueryOrderById(Matchers.any(), Matchers.any(), Matchers.any()))
				.thenThrow(new IOException(dummyExceptionMessage));

		ServiceFactory factory = new DefaultServiceFactory(mockDaoFactory);

		GlossaryService glossaryService = factory.getGlossaryService();

		try {
			GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 0, Integer.MAX_VALUE);
			glossaryService.search(query, LocalDate.now());
			fail("DAO methods was not invoked or exception was suppressed illegally");
		} catch (TransactionException e) {
			assertTrue(e.getCause() instanceof IOException);
			assertFalse(mockTransaction.isCommited());
			assertTrue(mockTransaction.isClosed());
		}
	}

	@Test
	public void testSearchFailOpenConnection() throws IOException, SQLException {
		DaoFactory mockDaoFactory = Mockito.mock(DaoFactory.class, Mockito.RETURNS_DEEP_STUBS);

		Mockito.when(mockDaoFactory.getDataStore())
				.thenReturn(new MockDataStoreFailBegin());

		ServiceFactory factory = new DefaultServiceFactory(mockDaoFactory);

		GlossaryService glossaryService = factory.getGlossaryService();

		try {
			GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 0, Integer.MAX_VALUE);
			glossaryService.search(query, LocalDate.now());
			fail("DataStore#begin() was not invoked or exception was suppressed illegally");
		} catch (TransactionException e) {
			assertTrue(e.getCause() instanceof IOException);
		}
	}

	@Test
	public void testSearchFailCloseConnection() throws IOException, SQLException {
		DaoFactory mockDaoFactory = createMockDaoFactory(
				1,
				Collections.singletonList(
						new GlossaryDto("1", "�Ă���1", "test1", "test remark", "CJK", "CJK.xls", LocalDate.now(), LocalDate.now())));

		MockTransaction mockTransaction = new MockTransaction(true, false, false);
		Mockito.when(mockDaoFactory.getDataStore().begin())
				.thenReturn(mockTransaction);

		ServiceFactory factory = new DefaultServiceFactory(mockDaoFactory);

		GlossaryService glossaryService = factory.getGlossaryService();

		try {
			GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 0, Integer.MAX_VALUE);
			glossaryService.search(query, LocalDate.now());
			fail("Transaction#close() methods was not invoked or exception was suppressed illegally");
		} catch (TransactionException e) {
			assertTrue(e.getCause() instanceof IOException);
		}
	}

	private DaoFactory createMockDaoFactory(int bookTotal, List<GlossaryDto> foundBooks) throws IOException {
		DaoFactory mockDaoFactory = Mockito.mock(DaoFactory.class, Mockito.RETURNS_DEEP_STUBS);

		MockTransaction mockTransaction = new MockTransaction();
		Mockito.when(mockDaoFactory.getDataStore().begin())
				.thenReturn(mockTransaction);

		Mockito.when(mockDaoFactory.getGlossaryDao().countWithQuery(Matchers.any(), Matchers.any(), Matchers.any()))
				.thenReturn(bookTotal);
		Mockito.when(mockDaoFactory.getGlossaryDao().searchWithQueryOrderById(Matchers.any(), Matchers.any(), Matchers.any()))
				.thenReturn(foundBooks);

		return mockDaoFactory;
	}

}
