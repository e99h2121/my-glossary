package com.worksap.glossary.web.api.dao.impl;

import java.io.File;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.dbunit.DataSourceDatabaseTester;
import org.dbunit.DatabaseUnitException;
import org.dbunit.IDatabaseTester;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.csv.CsvDataSet;
import org.dbunit.ext.h2.H2DataTypeFactory;
import org.dbunit.operation.DatabaseOperation;
import org.junit.rules.ExternalResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DBUnitRule extends ExternalResource {

	public class CommitOperation extends DatabaseOperation {

		private DatabaseOperation operation;

		public CommitOperation(DatabaseOperation operation) {
			this.operation = operation;
		}

		@Override
		public void execute(IDatabaseConnection connection, IDataSet dataSet)
				throws DatabaseUnitException, SQLException {
			operation.execute(connection, dataSet);
			connection.getConnection().commit();
		}

	}

	private IDatabaseTester databaseTester;
	private File testcaseDir;

	public DBUnitRule(DataSource dataSource, File testcaseDir) throws Exception {
		databaseTester = new DataSourceDatabaseTester(dataSource) {
			@Override
			public IDatabaseConnection getConnection() throws Exception {
				IDatabaseConnection connection = super.getConnection();
				connection.getConfig().setProperty(
						DatabaseConfig.PROPERTY_DATATYPE_FACTORY, new H2DataTypeFactory());
				return connection;
			}
		};
		databaseTester.setSetUpOperation(new CommitOperation(DatabaseOperation.CLEAN_INSERT));

		this.testcaseDir = testcaseDir;
	}

	@Override
	protected void before() throws Throwable {
		databaseTester.setDataSet(new CsvDataSet(testcaseDir));
		databaseTester.onSetup();
	}

	@Override
	protected void after() {
		try {
			databaseTester.onTearDown();
		} catch (Exception e) {
			log.error("Exception occured at tear down", e);
		}
	}
}
