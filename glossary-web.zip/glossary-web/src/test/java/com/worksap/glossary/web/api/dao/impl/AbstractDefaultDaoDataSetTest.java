package com.worksap.glossary.web.api.dao.impl;

import java.io.File;

import org.junit.ClassRule;
import org.junit.Rule;

import com.worksap.glossary.web.api.dao.impl.DefaultDaoFactory;

public class AbstractDefaultDaoDataSetTest {

	@ClassRule
	public static JNDIRule simpleJNDIRule = new JNDIRule();

	protected DefaultDaoFactory daoFactory = new DefaultDaoFactory();

	@Rule
	public DBUnitRule dbUnitRule;

	public AbstractDefaultDaoDataSetTest(File testcaseDir) throws Exception {
		dbUnitRule = new DBUnitRule(daoFactory.getDataSource(), testcaseDir);
	}
}
