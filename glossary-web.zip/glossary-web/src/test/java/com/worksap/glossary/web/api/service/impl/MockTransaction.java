package com.worksap.glossary.web.api.service.impl;

import static org.junit.Assert.assertFalse;

import java.io.IOException;
import java.sql.Connection;

import org.mockito.Mockito;

import com.worksap.glossary.web.api.dao.spec.Transaction;

public class MockTransaction implements Transaction {

	private boolean failOnClose = false;
	private boolean failOnCommit = false;
	private boolean failOnRollback = false;

	private boolean closed = false;
	private boolean commited = false;
	private boolean rollbacked = false;

	public MockTransaction() {
	}

	public MockTransaction(boolean failOnClose, boolean failOnCommit, boolean failOnRollback) {
		this.failOnClose = failOnClose;
		this.failOnCommit = failOnCommit;
		this.failOnRollback = failOnRollback;
	}

	@Override
	public Connection getJdbcConnection() {
		return Mockito.mock(Connection.class);
	}

	@Override
	public void close() throws IOException {
		if (failOnClose) {
			throw new IOException("Thrown for test");
		}

		closed = true;
	}

	@Override
	public void commit() throws IOException {
		if (failOnCommit) {
			throw new IOException("Thrown for test");
		}

		assertFalse(closed);
		commited = true;
	}

	@Override
	public void rollback() throws IOException {
		if (failOnRollback) {
			throw new IOException("Thrown for test");
		}

		assertFalse(closed);
		rollbacked = true;
	}

	public boolean isClosed() {
		return closed;
	}

	public boolean isCommited() {
		return commited;
	}

	public boolean isRollbacked() {
		return rollbacked;
	}
}
