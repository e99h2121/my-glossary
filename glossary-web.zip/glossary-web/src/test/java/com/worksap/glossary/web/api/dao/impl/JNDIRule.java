package com.worksap.glossary.web.api.dao.impl;

import java.util.concurrent.atomic.AtomicBoolean;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.naming.java.javaURLContextFactory;
import org.h2.jdbcx.JdbcDataSource;
import org.junit.rules.ExternalResource;

import com.worksap.glossary.web.api.dao.impl.DefaultDaoFactory;

public class JNDIRule extends ExternalResource {

	private static final String JDBC_URL = "jdbc:h2:~/.local/var/h2/obs-unittest;MVCC=TRUE;AUTOCOMMIT=FALSE;INIT=runscript from './obs-data-model/sql/tables.sql'";
	private static AtomicBoolean initialized = new AtomicBoolean(false);

	@Override
	protected void before() throws Throwable {
		if (initialized.compareAndSet(false, true)) {
			System.setProperty(Context.INITIAL_CONTEXT_FACTORY, javaURLContextFactory.class.getName());

			JdbcDataSource dataSource = new JdbcDataSource();
			dataSource.setURL(JDBC_URL);
			dataSource.setUser("");
			dataSource.setPassword("");

			InitialContext context = new InitialContext();
			context.createSubcontext("java:");
			context.createSubcontext("java:comp");
			context.createSubcontext("java:comp/env");
			context.createSubcontext("java:comp/env/jdbc");
			context.createSubcontext("java:comp/env/jdbc/bootcamp");
			context.bind(DefaultDaoFactory.DATASOURCE_NAME, dataSource);
		}
	}

	@Override
	protected void after() {
	}

}
