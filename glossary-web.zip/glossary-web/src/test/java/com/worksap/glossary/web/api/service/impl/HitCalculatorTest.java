package com.worksap.glossary.web.api.service.impl;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.worksap.glossary.web.api.service.impl.HitCalculator;
import com.worksap.glossary.web.api.vo.Hit;

public class HitCalculatorTest {

	/*
	 * Index is beginning from 0, the last is (n - 1) (according to array).
	 */

	@Test
	public void testFirstPage() {
		HitCalculator calcurator = new HitCalculator();

		// [0,20) items requested
		// 100 item matched
		Hit hit = calcurator.calculate(0, 20, 100);

		// Response [0,20) items of 100
		assertEquals(100, hit.getTotal());
		assertEquals(0, hit.getBegin());
		assertEquals(20, hit.getEnd());
	}

	@Test
	public void testMiddlePage() {
		HitCalculator calcurator = new HitCalculator();

		// [20,40) items requested
		// 100 item matched
		Hit hit = calcurator.calculate(20, 40, 100);

		// Response [20,40) items of 100
		assertEquals(100, hit.getTotal());
		assertEquals(20, hit.getBegin());
		assertEquals(40, hit.getEnd());
	}

	@Test
	public void testLastPage() {
		HitCalculator calcurator = new HitCalculator();

		// [80,100) items requested
		// 90 item matched
		Hit hit = calcurator.calculate(80, 100, 90);

		// response [80,90) items of 90
		assertEquals(90, hit.getTotal());
		assertEquals(80, hit.getBegin());
		assertEquals(90, hit.getEnd());
	}

	@Test
	public void testFewResult() {
		HitCalculator calcurator = new HitCalculator();

		// [0,20) items requested
		// Only 10 item matched
		Hit hit = calcurator.calculate(0, 20, 10);

		// Response [0,10) items of 10
		assertEquals(10, hit.getTotal());
		assertEquals(0, hit.getBegin());
		assertEquals(10, hit.getEnd());
	}

	@Test
	public void testResultLessThanBegin() {
		HitCalculator calcurator = new HitCalculator();

		// [60,80) items requested
		// Only 59 item matched
		Hit hit = calcurator.calculate(60, 80, 59);

		// Consider as fixed begin and found 0 items from the begin
		assertEquals(59, hit.getTotal());
		assertEquals(59, hit.getBegin());
		assertEquals(59, hit.getEnd());
	}
}
