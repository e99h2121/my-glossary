package com.worksap.glossary.web.api.dao.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import com.worksap.glossary.web.api.dao.spec.DataStore;
import com.worksap.glossary.web.api.dao.spec.GlossaryDao;
import com.worksap.glossary.web.api.dao.spec.Transaction;
import com.worksap.glossary.web.api.dto.GlossaryDto;
import com.worksap.glossary.web.api.vo.GlossarySearchQuery;

@RunWith(Enclosed.class)
public class DefaultGlossaryDaoImplTest {

	public static class EmptyDataSet extends AbstractDefaultDaoDataSetTest {

		public EmptyDataSet() throws Exception {
			super(Paths.get("src", "test", "dataset", "empty").toFile());
		}

		@Test
		public void test() throws IOException, SQLException {
			// Prepare
			DataStore dataStore = daoFactory.getDataStore();
			GlossaryDao glossaryDao = daoFactory.getGlossaryDao();

			try (Transaction transaction = dataStore.begin()) {
				// Act
				GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 0, Integer.MAX_VALUE);
				LocalDate now = LocalDate.now();

				int count = glossaryDao.countWithQuery(transaction, query, now);
				// Assert
				assertEquals(0, count);

				List<GlossaryDto> result = glossaryDao.searchWithQueryOrderById(transaction, query, now);
				assertTrue(result.isEmpty());
			}
		}
	}

	public static class GlossaryDataSet extends AbstractDefaultDaoDataSetTest  {

		public GlossaryDataSet() throws Exception {
			super(Paths.get("src", "test", "dataset", "book").toFile());
		}

		@Test
		public void test() throws IOException, SQLException {
			DataStore dataStore = daoFactory.getDataStore();
			GlossaryDao glossaryDao = daoFactory.getGlossaryDao();

			try (Transaction transaction = dataStore.begin()) {
				GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null,null,  0, Integer.MAX_VALUE);
				LocalDate now = LocalDate.now();

				int count = glossaryDao.countWithQuery(transaction, query, now);
				assertEquals(3, count);

				List<GlossaryDto> result = glossaryDao.searchWithQueryOrderById(transaction, query, now);
				assertEquals(3, result.size());
				assertEquals(1, result.get(0).getId());
				assertEquals(2, result.get(1).getId());
				assertEquals(3, result.get(2).getId());
			}
		}

		@Test
		public void testEmptyRange() throws IOException, SQLException {
			GlossaryDao glossaryDao = daoFactory.getGlossaryDao();
			DataStore dataStore = daoFactory.getDataStore();

			try (Transaction transaction = dataStore.begin()) {
				GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 0, 0);
				LocalDate now = LocalDate.now();

				int count = glossaryDao.countWithQuery(transaction, query, now);
				assertEquals(3, count);

				List<GlossaryDto> result = glossaryDao.searchWithQueryOrderById(transaction, query, now);
				assertTrue(result.isEmpty());
			}
		}

		@Test
		public void testOffsetRange() throws IOException, SQLException {
			DataStore dataStore = daoFactory.getDataStore();
			GlossaryDao glossaryDao = daoFactory.getGlossaryDao();

			try (Transaction transaction = dataStore.begin()) {
				GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null,null,  1, Integer.MAX_VALUE);
				LocalDate now = LocalDate.now();

				int count = glossaryDao.countWithQuery(transaction, query, now);
				assertEquals(3, count);

				List<GlossaryDto> result = glossaryDao.searchWithQueryOrderById(transaction, query, now);
				assertEquals(2, result.size());
				assertEquals(2, result.get(0).getId());
				assertEquals(3, result.get(1).getId());
			}
		}

		@Test
		public void testLimitRange() throws IOException, SQLException {
			DataStore dataStore = daoFactory.getDataStore();
			GlossaryDao glossaryDao = daoFactory.getGlossaryDao();

			try (Transaction transaction = dataStore.begin()) {
				GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 0, 2);
				LocalDate now = LocalDate.now();

				int count = glossaryDao.countWithQuery(transaction, query, now);
				assertEquals(3, count);

				List<GlossaryDto> result = glossaryDao.searchWithQueryOrderById(transaction, query, now);
				assertEquals(2, result.size());
				assertEquals(1, result.get(0).getId());
				assertEquals(2, result.get(1).getId());
			}
		}

		@Test
		public void testRange() throws IOException, SQLException {
			DataStore dataStore = daoFactory.getDataStore();
			GlossaryDao glossaryDao = daoFactory.getGlossaryDao();

			try (Transaction transaction = dataStore.begin()) {
				GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 1, 2);
				LocalDate now = LocalDate.now();

				int count = glossaryDao.countWithQuery(transaction, query, now);
				assertEquals(3, count);

				List<GlossaryDto> result = glossaryDao.searchWithQueryOrderById(transaction, query, now);
				assertEquals(1, result.size());
				assertEquals(2, result.get(0).getId());
			}
		}

		@Test
		public void testBeforeSale() throws IOException, SQLException {
			DataStore dataStore = daoFactory.getDataStore();
			GlossaryDao glossaryDao = daoFactory.getGlossaryDao();

			try (Transaction transaction = dataStore.begin()) {
				GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null, null, 0, Integer.MAX_VALUE);
				LocalDate now = LocalDate.of(2016, 2, 29);

				int count = glossaryDao.countWithQuery(transaction, query, now);
				assertEquals(2, count);

				List<GlossaryDto> result = glossaryDao.searchWithQueryOrderById(transaction, query, now);
				assertEquals(2, result.size());
				assertEquals(1, result.get(0).getId());
				assertEquals(2, result.get(1).getId());
			}
		}

		@Test
		public void testTitleQuery() throws IOException, SQLException {
			GlossaryDao glossaryDao = daoFactory.getGlossaryDao();
			DataStore dataStore = daoFactory.getDataStore();

			try (Transaction transaction = dataStore.begin()) {
				GlossarySearchQuery query = new GlossarySearchQuery("abcdefg", null, null, null, null, null, 0, Integer.MAX_VALUE);
				LocalDate now = LocalDate.now();

				int count = glossaryDao.countWithQuery(transaction, query, now);
				assertEquals(2, count);

				List<GlossaryDto> result = glossaryDao.searchWithQueryOrderById(transaction, query, now);
				assertEquals(2, result.size());
				assertEquals(1, result.get(0).getId());
				assertEquals(3, result.get(1).getId());
			}
		}

		@Test
		public void testPublisher() throws IOException, SQLException {
			DataStore dataStore = daoFactory.getDataStore();
			GlossaryDao glossaryDao = daoFactory.getGlossaryDao();

			try (Transaction transaction = dataStore.begin()) {
				GlossarySearchQuery query = new GlossarySearchQuery(null, null, null, null, null,  "bbb", 0, Integer.MAX_VALUE);
				LocalDate now = LocalDate.now();

				int count = glossaryDao.countWithQuery(transaction, query, now);
				assertEquals(2, count);

				List<GlossaryDto> result = glossaryDao.searchWithQueryOrderById(transaction, query, now);
				assertEquals(2, result.size());
				assertEquals(2, result.get(0).getId());
				assertEquals(3, result.get(1).getId());
			}
		}
	}
}
