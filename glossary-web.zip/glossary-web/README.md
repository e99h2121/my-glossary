## Getting Started

1. Run `mvn eclipse:eclipse` to create project
2. Import the generated project into Eclipse (File > Import > General > Existing Project ...)
3. Open *Servers* view (Window > Show View > Other > Server > Servers)
4. Add `DataSource` resource to `context.xml`
5. Set up Tomcat on Eclipse Web Tools Platform (WTP) plugin (Right click Servers view > New > Servers)
6. Add project to tomcat (Right click Servers view > Add)
7. Start H2 with server mode (*)
8. Start tomcat and open `http://localhost:8080/glossary-web/`

### Setup database

You can use the following command to start H2 database:

```
java -cp ~/.m2/repository/com/h2database/h2/1.4.190/h2-1.4.190.jar org.h2.tools.Server
```

`RunScript` is useful to run scripts in the submodule `obs-data-model`:

```
java -cp ~/.m2/repository/com/h2database/h2/1.4.190/h2-1.4.190.jar org.h2.tools.RunScript -url "jdbc:h2:tcp://127.0.1.1:9092/~/.local/var/h2/obs" -script ./obs-data-model/sql/tables.sql
```

And other scripts for sample data also can be used similarly.

### JDBC settings

Add settings for `DataSource` resource to `context.xml`
Don't forget to copy the H2 JDBC Driver's jar into `$CATALINA_HOME/lib`.

```
<Resource name="jdbc/bootcamp/datasource" auth="Container" type="javax.sql.DataSource"
	driverClassName="org.h2.Driver"
	url="jdbc:h2:tcp://127.0.1.1:9092/~/.local/var/h2/obs;MVCC=TRUE;AUTOCOMMIT=FALSE"
	username="" password="" defaultAutoCommit="false"
	factory="org.apache.tomcat.jdbc.pool.DataSourceFactory" />
```
