obs-data-model
===============

Data Model for Online Book Store