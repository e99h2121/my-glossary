#! ruby -Ku
require "kconv"

File.open("allData.tsv", 'w') { |file_w|
	bookId = 1

	Dir::glob("*.dat").each { |f|
		publisherName = File.basename(f, ".dat")

		begin
			record = [bookId.to_s, publisherName]
			bookId += 1

			File.foreach(f) do |line|
				if line.start_with?('     レコードNo.:') then
					if record.size > 2 then
						record = record.map { |data| data.strip }
						if record.size == 44 then
							record.push("")
						end
						file_w.write record.join("\t") + "\n"

						if record.size != 45 then
							p record
						end
						record = [bookId.to_s, publisherName]
						bookId += 1
					end
				elsif !line.strip.empty? then
					if record.size > 2 then
						record2 = line.chomp.split('$', -1)
						record[-1] = record[-1].to_s.strip + record2.shift.to_s.strip
						record += record2
					else
						record += line.chomp.split('$', -1)
					end
				end
			end

			record = record.map { |data| data.strip }
			if record.size == 44 then
				record.push("")
			end
			file_w.write record.join("\t") + "\n"
		rescue SystemCallError => e
			puts %Q(class=[#{e.class}] message=[#{e.message}])
		end
	}
}
