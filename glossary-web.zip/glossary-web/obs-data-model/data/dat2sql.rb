#! ruby -Ku
require "kconv"


class DatReader
	include Enumerable

	def initialize()
		@datFiles = Dir.glob("*.dat")
	end

	def each
		@datFiles.each { |f|
			publisherId = File.basename(f, ".dat")
			record = [publisherId]

			File.foreach(f) do |line|
				if line.start_with?('     レコードNo.:') then
					if record.size > 2 then
						yield record
						record = [publisherId]
					end
				elsif !line.strip.empty? then
					if record.size > 2 then
						record2 = line.chomp.split('$', -1)
						record[-1] = record[-1].to_s.strip + record2.shift.to_s.strip
						record += record2
					else
						record += line.chomp.split('$', -1)
					end
				end
			end

			yield record
		}
	end
end


class BookTableSQLWriter
	MERGE_SQL_START = "MERGE INTO BOOKS KEY (BOOK_ID) VALUES ("
	MERGE_SQL_END = ", CURRENT_TIMESTAMP);\n"

	def initialize(fileName = "Books.sql", startBookId = 1)
		@bookId = startBookId
		@file = File.open(fileName, 'w')
	end

	def close()
		if @file then
			@file.close
			@file = nil
		end
	end

	def write(record)
		data = format(record)
#		@file.write @bookId.to_s + "\t" + data.join("\t") + "\n"
		@file.write MERGE_SQL_START + @bookId.to_s + ", " + extractData(data) + MERGE_SQL_END 
		@bookId += 1
	end

	private
	def extractData(record)
#		TITLE, PUBLISHER_ID, ISBN, PRICE, PICTURE, RELEASE_DATE
		[
			getTitle(record),
			getPublisherId(record),
			getISBN(record),
			getPrice(record),
			"''",
			getReleaseDate(record)
		].join(", ")
	end

	def format(record)
		result = record.map { |data| data.strip }
		if result.size == 43 then
			result.push("")
		end
		if result.size != 44 then
			p result
		end
		result
	end

	def getISBN(record)
		if record[26].length > 0 then
			result = record[26].gsub(/[-:\s\(\)a-zA-YZ]/, "")

			if (result.length == 9) || (result.length == 12) then
				result = result + "X"
			end

			if result.length == 10 then
				result = "978" + result
			end
		else
			result = ("9784" + getPublisherId(record)).ljust(12, "0") + "0"
		end

		if result.gsub(/[0-9X]/, "").length > 0 then
			p record[26]
		end
		if result.length != 13 then
			p record[26]
		end

		"'" + result + "'"
	end

	def getPrice(record)
		if record[29].length > 0 then
			result = record[29].scan(/[0-9]+/).join(",")
		else
			result = "0"
		end

		if result.gsub(/[0-9]/, "").length > 0 then
			p record[29]
		end

		result
	end

	def getPublisherId(record)
		record[0]
	end

	def getReleaseDate(record)
		if record[14].length > 0 then
			temp = record[14].scan(/[0-9]+\.[0-9]+/).join(",")

			if temp.length == 0 then
				temp = record[14].scan(/[0-9]+/).join(",")
			end

			if temp.gsub(/[0-9\.]/, "").length > 0 then
				p record[14]
			end

			date = temp.scan(/[0-9]+/)

			if date.length > 0 then
				if date[0].length == 2 then
					if date[0] > 50 then
						date[0] = "19" + date[0]
					else
						date[0] = "20" + date[0]
					end
				end
			end

			if date.length == 3 then
				result = "'" + date[0] + "-" + date[1].rjust(2, "0") + "-" + date[2].rjust(2, "0") + "'" 
			elsif date.length == 2 then
				result = "'" + date[0] + "-" + date[1].rjust(2, "0") + "-01'"
			elsif date.length == 1 then
				result = "'" + date[0] + "-01-01'"
			else
				result = "'1900-01-01'"
			end
		else
			result = "'1900-01-01'"
		end

		if result.length != 12 then
			p result
		end

		result
	end

	def getTitle(record)
		"'" + record[7].gsub(/'/, "''") + "'"
	end
end


class StockTableSQLWriter
	MERGE_SQL_START = "MERGE INTO STOCKS KEY (BOOK_ID) VALUES ("
	MERGE_SQL_END = ", 999999, CURRENT_TIMESTAMP);\n"

	def initialize(fileName = "Stocks.sql", startBookId = 1)
		@bookId = startBookId
		@file = File.open(fileName, 'w')
	end

	def close()
		if @file then
			@file.close
			@file = nil
		end
	end

	def write()
		@file.write MERGE_SQL_START + @bookId.to_s + MERGE_SQL_END 
		@bookId += 1
	end
end


begin
	bookWriter = BookTableSQLWriter.new()
	stockWriter = StockTableSQLWriter.new()
	reader = DatReader.new()

	reader.map { |record|
		bookWriter.write(record)
		stockWriter.write()
	}
rescue SystemCallError => e
	puts %Q(class=[#{e.class}] message=[#{e.message}])
end
